#pragma once
#include <Windows.h>
#include <cstdint>

uint64_t Decrypt(uint64_t Value);

DWORD Decrypt_CIndex(DWORD v13);